.\Get-PreferredLocation.ps1
.\Update-AKS.ps1